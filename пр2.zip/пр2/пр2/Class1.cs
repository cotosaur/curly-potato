﻿namespace MyLibrary
{
    public class Zadanie
    {
        public void Hello()
        {
            Console.WriteLine("Привет");
        }

        public void Date_Time()
        {
            Console.WriteLine("Дата и время: " + DateTime.Now);
        }

        // Методы с возвращаемыми значениями
        public int Sum(int a, int b)
        {
            return a + b;
        }

        public string Name(string name)
        {
            return "Твое имя: " + name + "!";
        }

        public bool Parity(int number)
        {
            return number % 2 == 0;
        }
    }
}
