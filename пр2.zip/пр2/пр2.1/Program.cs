﻿using System;
using MyLibrary;  // подключаем нашу DLL

namespace MyApp
{
    class Program
    {
        static void Main()
        {
            Zadanie MyLibrary = new Zadanie();


            MyLibrary.Hello();
            MyLibrary.Date_Time();


            Console.WriteLine("\nвозвращенные значения :");

            int sum = MyLibrary.Sum(5, 7);
            Console.WriteLine("Сумма: " + sum);

            bool parity = MyLibrary.Parity(7);
            Console.WriteLine("Число 6 нечетное? " + parity);

            string str = MyLibrary.Name("Вероника");
            Console.WriteLine(str);



        }


    }
}
