﻿class Program  
{
    static void Main()  
    {
        try  // Начинаем блок, где может произойти ошибка
        {
            
            Console.Write("Введите первое число: ");
            int a = int.Parse(Console.ReadLine()); 

            
            Console.Write("Введите второе число: ");
            int b = int.Parse(Console.ReadLine()); 

            
            Console.Write("Выберите операцию (+, -, *, /): ");
            string operation = Console.ReadLine();  // Читаем введенную операцию

            int result = 0; 

            // Проверяем какую операцию выбрал пользователь
            if (operation == "+")
                result = a + b; 
            else if (operation == "-")
                result = a - b;
            else if (operation == "*")
                result = a * b;  
            else if (operation == "/")
                result = a / b;  
            else
                throw new Exception("Неизвестная операция!");  // ошибка если операция неправильная

          
            Console.WriteLine($"Результат: {a} {operation} {b} = {result}");
        }
        catch (FormatException)  // Ловим ошибку "неправильный формат числа"
        {
            Console.WriteLine("Ошибка: Введите числа правильно!");
        }
        catch (DivideByZeroException)  //ошибка "деление на ноль"
        {
            Console.WriteLine("Ошибка: Нельзя делить на ноль!");
        }
        catch (Exception ex)  //остальные ошибки
        {
            Console.WriteLine($"Ошибка: {ex.Message}");  
        }
        finally  // Этот блок выполнится в любом случае
        {
            Console.WriteLine("Калькулятор завершил работу."); 
        }
    }
}